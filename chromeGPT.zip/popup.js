// Listen for the submit button being clicked
const submitButton = document.getElementById('submit');



// Define the sendMessage function in the global scope
window.sendMessage = function() {
  // Get the input and output textarea elements
  const inputTextarea = document.getElementById('input');
  const outputTextarea = document.getElementById('output');

  // Get the message from the input textarea
  const message = inputTextarea.value;

  // Clear the input textarea
  inputTextarea.value = '';

  // Send the message to the OpenAI API
  fetch('https://api.openai.com/v1/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer <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>',
    },
    body: JSON.stringify({
      prompt: message,
      model: 'text-davinci-002',
      temperature: 0.5
    })
  })
  .then(response => response.json())
  .then(data => {
    // Get ChatGPT's response from the API response
    const response = data.choices[0].text;

    // Append ChatGPT's response to the output textarea
    outputTextarea.value += `\nChatGPT: ${response}`;

    // Clear the input textarea
    inputTextarea.value = ''; 
  })
  .catch(error => {
    // Handle any errors that occurred during the request
    console.error(error);

    // Append an error message to the output textarea
    outputTextarea.value += `\nAn error occurred while sending the message: ${error.message}`;
  });
};
submitButton.addEventListener('click', sendMessage);

