window.onload = function() {
    // Listen for the submit button being clicked
    const submitButton = document.getElementById('submit'); 
    const apiKeyInput = document.getElementById('api-key');
    const submitApiKeyButton = document.getElementById('submit-api-key');
    const apiKeyLabel = document.getElementById('api-key-label');
    let apikey;

    submitApiKeyButton.addEventListener('click', () => {
// Retrieve the API key from the input field
apiKey = apiKeyInput.value;
console.log(apiKey);

// Hide the API key input field and submit button
apiKeyInput.style.display = 'none';
submitApiKeyButton.style.display = 'none';
apiKeyLabel.style.display = 'none';          
});



    // Define the sendMessage function in the local scope
    function sendMessage() {
      // Get the input and output textarea elements
      const inputTextarea = document.getElementById('input');
      const outputTextarea = document.getElementById('output');

      // Get the message from the input textarea
      const message = inputTextarea.value;
      

      // Clear the input textarea
      inputTextarea.value = '';

      // Send the message to the OpenAI API
      
      fetch('https://api.openai.com/v1/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          prompt: message,
          model: 'text-davinci-003',
          temperature: 0.1,
          max_tokens: 4000
        })
      })

      .then(response => response.json())
      .then(data => {
        // Check if the choices property exists before trying to access it
        console.log(data);
        const response = data.choices && data.choices[0].text;

        // Append ChatGPT's response to the output textarea
        outputTextarea.value += `\nChatGPT: ${response}`;

        // Clear the input textarea
        inputTextarea.value = '';
      })
      .then(response => {
        console.log(response);
        
})

      .catch(error => {
        // Handle any errors that occurred during the request
         // Handle any errors that occurred during the request
console.error(error);

// Append an error message to the output textarea
outputTextarea.value += `\nAn error occurred while sending the message: ${error.message}`;
});
};

submitButton.addEventListener('click', sendMessage);}